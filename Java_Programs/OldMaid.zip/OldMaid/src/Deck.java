/*
 * The Deck Class
 */

 import java.util.*;

/**
 *
 * @author Sarah
 */
public class Deck {
    
    // contains all 53 cards (52 regular cards, 1 Joker)
    private final Card[] allCards;

    // contains all the cards currently in th deck
    private ArrayList<Card> cardStack;
    
    
    /**
     * Creates a new deck of cards
     */
    public Deck() {
        
        Card Joker = new JokerCard();
        
        Card ClubsA = new RegularCard("A", "♣", "ClubsA.png");
        Card Clubs2 = new RegularCard("2", "♣", "Clubs2.png");
        Card Clubs3 = new RegularCard("3", "♣", "Clubs3.png");
        Card Clubs4 = new RegularCard("4", "♣", "Clubs4.png");
        Card Clubs5 = new RegularCard("5", "♣", "Clubs5.png");
        Card Clubs6 = new RegularCard("6", "♣", "Clubs6.png");
        Card Clubs7 = new RegularCard("7", "♣", "Clubs7.png");
        Card Clubs8 = new RegularCard("8", "♣", "Clubs8.png");
        Card Clubs9 = new RegularCard("9", "♣", "Clubs9.png");
        Card Clubs10 = new RegularCard("10", "♣", "Clubs10.png");
        Card ClubsJ = new RegularCard("J", "♣", "ClubsJ.png");
        Card ClubsQ = new RegularCard("Q", "♣", "ClubsQ.png");
        Card ClubsK = new RegularCard("K", "♣", "ClubsK.png");
        
        Card DiamondsA = new RegularCard("A", "♦", "DiamondsA.png");
        Card Diamonds2 = new RegularCard("2", "♦", "Diamonds2.png");
        Card Diamonds3 = new RegularCard("3", "♦", "Diamonds3.png");
        Card Diamonds4 = new RegularCard("4", "♦", "Diamonds4.png");
        Card Diamonds5 = new RegularCard("5", "♦", "Diamonds5.png");
        Card Diamonds6 = new RegularCard("6", "♦", "Diamonds6.png");
        Card Diamonds7 = new RegularCard("7", "♦", "Diamonds7.png");
        Card Diamonds8 = new RegularCard("8", "♦", "Diamonds8.png");
        Card Diamonds9 = new RegularCard("9", "♦", "Diamonds9.png");
        Card Diamonds10 = new RegularCard("10", "♦", "Diamonds10.png");
        Card DiamondsJ = new RegularCard("J", "♦", "DiamondsJ.png");
        Card DiamondsQ = new RegularCard("Q", "♦", "DiamondsQ.png");
        Card DiamondsK = new RegularCard("K", "♦", "DiamondsK.png");
        
        Card HeartsA = new RegularCard("A", "♥", "HeartsA.png");
        Card Hearts2 = new RegularCard("2", "♥", "Hearts2.png");
        Card Hearts3 = new RegularCard("3", "♥", "Hearts3.png");
        Card Hearts4 = new RegularCard("4", "♥", "Hearts4.png");
        Card Hearts5 = new RegularCard("5", "♥", "Hearts5.png");
        Card Hearts6 = new RegularCard("6", "♥", "Hearts6.png");
        Card Hearts7 = new RegularCard("7", "♥", "Hearts7.png");
        Card Hearts8 = new RegularCard("8", "♥", "Hearts8.png");
        Card Hearts9 = new RegularCard("9", "♥", "Hearts9.png");
        Card Hearts10 = new RegularCard("10", "♥", "Hearts10.png");
        Card HeartsJ = new RegularCard("J", "♥", "HeartsJ.png");
        Card HeartsQ = new RegularCard("Q", "♥", "HeartsQ.png");
        Card HeartsK = new RegularCard("K", "♥", "HeartsK.png");
        
        Card SpadesA = new RegularCard("A", "♠", "SpadesA.png");
        Card Spades2 = new RegularCard("2", "♠", "Spades2.png");
        Card Spades3 = new RegularCard("3", "♠", "Spades3.png");
        Card Spades4 = new RegularCard("4", "♠", "Spades4.png");
        Card Spades5 = new RegularCard("5", "♠", "Spades5.png");
        Card Spades6 = new RegularCard("6", "♠", "Spades6.png");
        Card Spades7 = new RegularCard("7", "♠", "Spades7.png");
        Card Spades8 = new RegularCard("8", "♠", "Spades8.png");
        Card Spades9 = new RegularCard("9", "♠", "Spades9.png");
        Card Spades10 = new RegularCard("10", "♠", "Spades10.png");
        Card SpadesJ = new RegularCard("J", "♠", "SpadesJ.png");
        Card SpadesQ = new RegularCard("Q", "♠", "SpadesQ.png");
        Card SpadesK = new RegularCard("K", "♠", "SpadesK.png");
        
        allCards = new Card[] {Joker, ClubsA, Clubs2, Clubs3, Clubs4, Clubs5, Clubs6, Clubs7, Clubs8, Clubs9, Clubs10, ClubsJ, ClubsQ, ClubsK, DiamondsA, Diamonds2, Diamonds3, Diamonds4, Diamonds5, Diamonds6, Diamonds7, Diamonds8, Diamonds9, Diamonds10, DiamondsJ, DiamondsQ, DiamondsK, HeartsA, Hearts2, Hearts3, Hearts4, Hearts5, Hearts6, Hearts7, Hearts8, Hearts9, Hearts10, HeartsJ, HeartsQ, HeartsK, SpadesA, Spades2, Spades3, Spades4, Spades5, Spades6, Spades7, Spades8, Spades9, Spades10, SpadesJ, SpadesQ, SpadesK};
        
        // copies all cards in allCards into cardStack
        cardStack = new ArrayList<>(Arrays.asList(allCards));
    }
    
    
    /**
     * shuffles the cards in the array list cards
     */
    public void shuffle() {
        Collections.shuffle(cardStack);
        Collections.shuffle(cardStack);
    }
    
    
    /**
     * Removes the card at the "top" of the card stack
     * @return the card at the "top" of the card stack
     */
    public Card draw() {
        Card topCard = cardStack.get(cardStack.size() - 1);
        cardStack.remove(topCard);
        return topCard;
    }
    
    
    /**
     * 
     * @return true if cardStack is empty; false otherwise
     */
    public boolean isEmpty() {
        return cardStack.isEmpty();
    }
    
    
    /**
     * Restores the card stack to contain all the cards
     */
    public void replenish() {
        cardStack.clear();
        cardStack = new ArrayList<>(Arrays.asList(allCards));
    }
    
}
