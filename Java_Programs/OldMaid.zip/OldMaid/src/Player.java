/*
 * The Player Class
 */

import java.util.ArrayList;

/**
 *
 * @author Sarah
 */
public abstract class Player {
   
    // the name of the player
    protected String name;
    
    // the cards the player is holding in their hand
    protected ArrayList<Card> hand;
    
    
    /**
     * takes a random card from another player's hand
     * @param p the other player
     * @return a card from the other player's hand
     */
    public abstract Card takeRandomCard(Player p);
    
    
    /**
     * takes a particular card from another player's hand
     * @param player the other player
     * @param card the card from the player
     * @return the card
     */
    public Card takeCard(Player player, Card card) {
        player.hand.remove(card);
        
        this.hand.add(card);
        
        return card;
    }
    
    
    /**
     * Adds a card into the player's hand
     * @param card the card being added
     */
    public void drawCard(Card card) {
        hand.add(card);
    }
    
    
    /**
     * 
     * @return the player's name
     */
    public String getName() {
        return name;
    }
    
    
    /**
     * Changes the player's name
     * @param newName the new name of the player
     */
    public void changeName(String newName) {
        name = newName;
    }
    
    
    /**
     * Removes all the pairs from the player's hand
     */
    public void updateHand() {
        ArrayList<String> nonPairs = new ArrayList();
        ArrayList<Card> pairCards =  new ArrayList();
        
        for (Card c : hand) {
            if (nonPairs.contains(c.value)) {
                nonPairs.remove(c.value);
            } else {
                nonPairs.add(c.value);
            }
        }
        
        for (Card c : hand) {
            if (nonPairs.contains(c.value)) {
                nonPairs.remove(c.value);
            } else {
                pairCards.add(c);
            }
        }
        
        for (Card c : pairCards) {
            hand.remove(c);
        }
        
    }
    

    /**
     * Adds a new card to the hand if it doesn't have a pair; else removes it and its pair from the hand
     * @param newCard the new card
     */
    public void updateHand(Card newCard) {
        boolean isPair = false;
        Card pair = newCard;
        
        for (Card card : hand) {
            if (card != newCard) {
                if (Card.matches(card, newCard)) {
                    pair = card;
                    isPair = true;
                    break;
                }
            }
        }
        if (isPair) {
            hand.remove(pair);
            hand.remove(newCard);
        }
    }
    
}
