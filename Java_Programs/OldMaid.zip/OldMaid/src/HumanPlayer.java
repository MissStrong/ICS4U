/*
 * The Human Player Class
 */

import java.util.ArrayList;

/**
 *
 * @author Sarah
 */
public class HumanPlayer extends Player {
    
    /**
     * Creates a new human player
     * @param name the player's name
     */
    public HumanPlayer(String name) {
        this.name = name;
        hand = new ArrayList();
    }
    
    
    /**
     * takes a random card from another player's hand
     * @param p the other player
     * @return a card from the other player's hand
     */
    @Override
    public Card takeRandomCard(Player p) {
        Card random = p.hand.get((int)(Math.random() * p.hand.size()));
        
        p.hand.remove(random);
        
        hand.add(random);
        
        return random;
    }
    
}