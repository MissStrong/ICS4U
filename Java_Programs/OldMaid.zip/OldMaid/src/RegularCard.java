/*
 * The Regular Card Class
 */

import javax.swing.*;

/**
 *
 * @author Sarah
 */
public class RegularCard extends Card {
    
    // possible suits: ♣, ♦, ♥, ♠
    private final String suit;
    
    
    /**
     * Creates a new Regular card (not a Joker)
     * @param value the value of the card
     * @param suit the suit of the card
     * @param imageFile the .png image file of the card
     */
    public RegularCard(String value, String suit, String imageFile) {
        this.value = value;
        this.suit = suit;
        this.image = new ImageIcon("src/Images/" + imageFile);
    }
    
    
    /**
     * 
     * @return the suit of the card 
     */
    public String getSuit() {
        return suit;
    }
}
