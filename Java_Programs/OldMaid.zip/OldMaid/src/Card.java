/*
 * The Card Class
 */

import javax.swing.*;

/**
 *
 * @author Sarah
 */
public abstract class Card {
    
    // possible values: A, 2, 3, 4, 5, 6, 7, 8, 9, 10, J, Q, K, Joker
    protected String value;
    
    // a 46x68 .png file
    protected ImageIcon image;
    
    
    /**
     * 
     * @return the value of the card
     */
    public String getValue() {
        return value;
    }
    
    
    /**
     * 
     * @return the image of the card
     */
    public ImageIcon getImage() {
        return image;
    }
    
    
    /**
     * 
     * @param c1 a card
     * @param c2 a card
     * @return true if the two cards have the same value; false otherwise
     */
    public static boolean matches(Card c1, Card c2) {
        return c1.value.equals(c2.value);
    }
    
}
