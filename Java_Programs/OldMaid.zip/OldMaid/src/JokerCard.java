/*
 * The Joker Card Class
 */

import javax.swing.ImageIcon;

/**
 *
 * @author Sarah
 */
public class JokerCard extends Card {
    
    /**
     * Creates a new Joker card
     */
    public JokerCard() {
        value = "Joker";
        image = new ImageIcon("src/Images/Joker.png");
    }
    
}
