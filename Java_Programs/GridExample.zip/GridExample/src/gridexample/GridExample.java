/*
 * An example of a 2D array.
 */
package gridexample;
import java.util.Arrays;

/**
 *
 * @author Sarah
 */
public class GridExample {
    
    /**
     * This method returns the transpose of a 2D array of integers.
     * The transpose is the result when the rows become columns and vice versa.
     * 
     * @param grid a two-dimensional array of integers
     * @return the transpose of grid
     */
    public static int[][] transpose(int[][] grid) {
        int[][] gridT = new int[grid[0].length][grid.length];
        
        for (int i = 0; i < grid[0].length; i++) {
            for (int j = 0; j < grid.length; j++) {
                gridT[i][j] = grid[j][i];
            }
        }
        
        return gridT;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] row0 = {1, 2, 3};
        int[] row1 = {4, 5, 6};
        int[] row2 = {7, 8, 9};
        int[][] grid = {row0, row1, row2};
        
        System.out.println("Here is the grid:");
        for (int[] row : grid) {
            System.out.println(Arrays.toString(row));
        }
        
        System.out.println();
        System.out.println("Here is the transpose of the grid:");
        for (int[] row : transpose(grid)) {
            System.out.println(Arrays.toString(row));
        }

        /*
         *  Note: the code below (lines 56-58) does not work.
         *
         *  int[][] gridR = new int[3][3];
         *
         *  gridR[0] = {row0[2], row0[1], row0[0]};
         *  gridR[1] = {row1[2], row1[1], row1[0]};
         *  gridR[2] = {row2[2], row2[1], row2[0]};
         */
        
        // Instead, you have to initiaize one element at a time.
        
        int[][] gridR = new int[3][3];
        
        gridR[0][0] = row0[2];
        gridR[0][1] = row0[1];
        gridR[0][2] = row0[0];
        
        gridR[1][0] = row1[2];
        gridR[1][1] = row1[1];
        gridR[1][2] = row1[0];
        
        gridR[2][0] = row2[2];
        gridR[2][1] = row2[1];
        gridR[2][2] = row2[0];
        
        System.out.println();
        System.out.println("Here is the grid with each row reversed:");
        for (int[] row : gridR) {
            System.out.println(Arrays.toString(row));
        }

        System.out.println();
        System.out.println("Here is the grid with each column reversed:");
        for (int[] row : transpose(gridR)) {
            System.out.println(Arrays.toString(row));
        }
    }
    
}
