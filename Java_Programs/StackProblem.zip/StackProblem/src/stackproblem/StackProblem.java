/*
 * An application of the stack ADT.
 */
package stackproblem;
import java.util.*;

/**
 *
 * @author Sarah
 */
public class StackProblem {
    
    /**
     * Checks whether all the brackets and braces in a string are balanced.
     * Brackets (and braces) are the following : '(', ')', '[', ']', '{', '}', '<' , '>'.
     * 
     * This method uses the Stack class.
     * 
     * @param s a string 
     * @return true if the brackets (and braces) in the string are balanced; false otherwise
     */
    public static boolean isBalancedV1(String s) {
        
        // This stack is going to keep track of all the open brackets that 
        // haven't been closed yet
        Stack<Character> charStack = new Stack();
        
        for (int i = 0; i < s.length(); i++) {
            char current = s.charAt(i);
            
            if (current == '(' || current == '[' || current == '{' || current == '<') {
                // The open bracket is added to the stack
                charStack.add(current);
            } else if (!charStack.isEmpty()) {
                char previous = charStack.peek();
                
                boolean case1 = (previous == '(' && current == ')');
                boolean case2 = (previous == '[' && current == ']');
                boolean case3 = (previous == '{' && current == '}');
                boolean case4 = (previous == '<' && current == '>');
                
                if (case1 || case2 || case3 || case4) {
                    // The current bracket closes the previous bracket, so the
                    // previous bracket is removed
                    charStack.pop();
                    continue;
                }
            }
            
            if (current == ')' || current == ']' || current == '}' || current == '>') {
                // The current bracker is a closed bracket that doesn't have
                // a corresponding open bracket, so the brackets aren't balanced
                return false;
            }
        }
        
        // All the open brackets have been closed, so the brackets are balanced
        if (charStack.isEmpty()) return true;
        // There are open brackets left, so the brackets aren't balanced
        return false;
    }
    
    
    /**
     * Checks whether all the brackets and braces in a string are balanced.
     * Brackets (and braces) are the following : '(', ')', '[', ']', '{', '}', '<' , '>'.
     * 
     * This method does not use the Stack class, which makes this method more 
     * difficult to understand.
     * 
     * @param s a string 
     * @return true if the brackets (and braces) in the string are balanced; false otherwise
     */
    public static boolean isBalancedV2(String s) {
        
        // This array list is going to keep track of all the open brackets that 
        // haven't been closed yet
        ArrayList<Character> charArrayList = new ArrayList();
        
        for (int i = 0; i < s.length(); i++) {
            char current = s.charAt(i);
            
            if (current == '(' || current == '[' || current == '{' || current == '<') {
                // The open bracket is added to the stack
                charArrayList.add(current);
            } else if (!charArrayList.isEmpty()) {
                char previous = charArrayList.get(charArrayList.size()-1);
                
                boolean case1 = (previous == '(' && current == ')');
                boolean case2 = (previous == '[' && current == ']');
                boolean case3 = (previous == '{' && current == '}');
                boolean case4 = (previous == '<' && current == '>');
                
                if (case1 || case2 || case3 || case4) {
                    // The current bracket closes the previous bracket, so the
                    // previous bracket is removed
                    charArrayList.remove(charArrayList.get(charArrayList.size()-1));
                    continue;
                }
            }
            
            if (current == ')' || current == ']' || current == '}' || current == '>') {
                // The current bracker is a closed bracket that doesn't have
                // a corresponding open bracket, so the brackets aren't balanced
                return false;
            }
        }
        
        // All the open brackets have been closed, so the brackets are balanced
        if (charArrayList.isEmpty()) return true;
        // There are open brackets left, so the brackets aren't balanced
        return false;
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Tests for isBalancedV1()");
        System.out.println();
        System.out.println("These six cases should print \"true\"");
        System.out.println(isBalancedV1(""));
        System.out.println(isBalancedV1("()"));
        System.out.println(isBalancedV1("(q)[]"));
        System.out.println(isBalancedV1("[() ]"));
        System.out.println(isBalancedV1("<> <()>"));
        System.out.println(isBalancedV1(" {{}}(3)"));
        
        System.out.println();
        
        System.out.println("These six cases should print \"false\"");
        System.out.println(isBalancedV1("("));
        System.out.println(isBalancedV1("]"));
        System.out.println(isBalancedV1("{(){}"));
        System.out.println(isBalancedV1("([)]"));
        System.out.println(isBalancedV1("<](]"));
        System.out.println(isBalancedV1("<()>]["));
        System.out.println();
        
        System.out.println("Tests for isBalancedV2()");
        System.out.println();
        
        System.out.println("These six cases should print \"true\"");
        System.out.println(isBalancedV2(""));
        System.out.println(isBalancedV2("()"));
        System.out.println(isBalancedV2("(q)[]"));
        System.out.println(isBalancedV2("[() ]"));
        System.out.println(isBalancedV2("<> <()>"));
        System.out.println(isBalancedV2(" {{}}(3)"));
        
        System.out.println();
        
        System.out.println("These six cases should print \"false\"");
        System.out.println(isBalancedV2("("));
        System.out.println(isBalancedV2("]"));
        System.out.println(isBalancedV2("{(){}"));
        System.out.println(isBalancedV2("([)]"));
        System.out.println(isBalancedV2("<](]"));
        System.out.println(isBalancedV2("<()>]["));
        
    }
    
}
