/*
* Solutions to examples demonstrating binary search algorithms
 */
package binarysearch;

import java.util.Arrays;

/**
 *
 * @author Sarah
 */
public class BinarySearch {
    
    /** 
     * This method takes an array of integers in ascending order, and an integer, and performs a 
     * binary search using an iterative approach.
     * 
     * @param array An array of integers.
     * @param n An integer.
     * @return true if integer is in array; false otherwise.
     */
    public static boolean searchV1(int[] array, int n) {
        if (/* Is the array empty? */) return false;
        int lowerBound = 0;
        int upperBound = array.length - 1;
        while (true) {
            // mid is the index in the middle of the array (rounding down)
            int mid = (upperBound + lowerBound) / 2; 
            if (/* Is there only one element left, which doesn't match n? */) {
                return false;
            }
            if (array[mid] > n) {
                upperBound = /* What is the new upper bound? */;
            } else if (array[mid] < n) {
                lowerBound = /* What is the new lower bound? */;
            } else {
                return true;
            }	
        }
    }
    
    /** 
     * This method takes an array of integers in ascending order, and an integer, and performs a 
     * binary search using a recursive approach.
     * 
     * @param array An array of integers.
     * @param n An integer.
     * @return true if integer is in array; false otherwise.
     */
    public static boolean searchV2(int[] array, int n) {
        if (/* Is the array NOT empty? */) {
            int mid = (array.length - 1) / 2;
            int candidate = /* Which element are we checking? */;
            if (candidate == n) {
                return true;
            }
            int[] smallerArray;
            if (/* Is the candidate less than n? */) {
                smallerArray = Arrays.copyOfRange(array, mid + 1, array.length);
            } else {
                smallerArray = Arrays.copyOfRange(array, 0, mid);
            }
            return searchV2(smallerArray, n);
        }
        return false;
    }
    
    
    // Don't modify lines 71-80.
    
    /** This method takes two booleans and returns "PASS" if they are the same, and
     * "NOT PASS" otherwise
     * @param b1 a boolean that represents the intended result from search()
     * @param b2 a boolean that represents the actual result from search()
     * @return True if integer is in array, and false otherwise.
     */
    public static String test(boolean b1, boolean b2) {
        if (b1 == b2) return "PASS";
        else return "NOT PASS";
    }
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] arrayA = {};
        int[] arrayB = {3};
        int[] arrayC = {-5, -1};
        int[] arrayD = {1, 3, 5};
        int[] arrayE = {-10, -9, 0, 0, 1, 8};
        
        // All 32 tests should pass without any exceptions thrown
        
        System.out.println("Test 1: " + test(false, searchV1(arrayA, 3)));
        System.out.println("Test 2: " + test(true, searchV1(arrayB, 3)));
        System.out.println("Test 3: " + test(false, searchV1(arrayB, 2)));
        System.out.println("Test 4: " + test(true, searchV1(arrayC, -5)));
        System.out.println("Test 5: " + test(true, searchV1(arrayC, -1)));
        System.out.println("Test 6: " + test(false, searchV1(arrayC, 0)));
        System.out.println("Test 7: " + test(true, searchV1(arrayD, 1)));
        System.out.println("Test 8: " + test(true, searchV1(arrayD, 3)));
        System.out.println("Test 9: " + test(true, searchV1(arrayD, 5)));
        System.out.println("Test 10: " + test(false, searchV1(arrayD, 7)));
        System.out.println("Test 11: " + test(true, searchV1(arrayE, -10)));
        System.out.println("Test 12: " + test(true, searchV1(arrayE, -9)));
        System.out.println("Test 13: " + test(true, searchV1(arrayE, 0)));
        System.out.println("Test 14: " + test(true, searchV1(arrayE, 1)));
        System.out.println("Test 15: " + test(true, searchV1(arrayE, 8)));
        System.out.println("Test 16: " + test(false, searchV1(arrayE, 7)));
        
        System.out.println("Test 17: " + test(false, searchV2(arrayA, 3)));
        System.out.println("Test 18: " + test(true, searchV2(arrayB, 3)));
        System.out.println("Test 19: " + test(false, searchV2(arrayB, 2)));
        System.out.println("Test 20: " + test(true, searchV2(arrayC, -5)));
        System.out.println("Test 21: " + test(true, searchV2(arrayC, -1)));
        System.out.println("Test 22: " + test(false, searchV2(arrayC, 0)));
        System.out.println("Test 23: " + test(true, searchV2(arrayD, 1)));
        System.out.println("Test 24: " + test(true, searchV2(arrayD, 3)));
        System.out.println("Test 25: " + test(true, searchV2(arrayD, 5)));
        System.out.println("Test 26: " + test(false, searchV2(arrayD, 7)));
        System.out.println("Test 27: " + test(true, searchV2(arrayE, -10)));
        System.out.println("Test 28: " + test(true, searchV2(arrayE, -9)));
        System.out.println("Test 29: " + test(true, searchV2(arrayE, 0)));
        System.out.println("Test 30: " + test(true, searchV2(arrayE, 1)));
        System.out.println("Test 31: " + test(true, searchV2(arrayE, 8)));
        System.out.println("Test 32: " + test(false, searchV2(arrayE, 7)));
    }
    
}
