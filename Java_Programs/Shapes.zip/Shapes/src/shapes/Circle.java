/*
 * Assignment 4
 */
package shapes;

/**
 *
 * @author anonymous
 */
public class Circle {
    
    /*
     * Fill in the documentation here
     */
    public static double area(double r) {
        /*
         * Figure out what goes here
         */   
    }
 
    /*
     * Fill in the documentation here
     */
    public static double circumference(double r) {
        /*
         * Figure out what goes here
         */   
        
    }
    
}
