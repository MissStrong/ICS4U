/*
 * Assignment 4
 */
package shapes;

/**
 *
 * @author anonymous
 */
public class Shapes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Tests for Rectangle.area
        // Put your tests here
        
        // Tests for Rectangle.perimeter
        // Put your tests here
        
        // Tests for Triangle.area
        // Put your tests here
        
        // Tests for Triangle.perimeter
        // Put your tests here
        
        // Tests for Circle.perimeter
        // Put your tests here
        
        // Tests for Circle.perimeter
        // Put your tests here
    }
    
}
