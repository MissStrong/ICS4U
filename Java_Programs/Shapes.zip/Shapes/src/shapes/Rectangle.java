/*
 * Assignment 4
 */
package shapes;

/**
 *
 * @author anonymous
 */
public class Rectangle {
    
    /**
     * This method takes the length and width of a rectangle and returns the rectangle's area.
     * @param l the length of the rectangle
     * @param w the width of the rectangle
     * @return the area of the rectangle with length l and width w
     */
    public static double area(double l, double w) {
        return l*w;
    }
 
    /*
     * Fill in the documentation here
     */
    public static double perimeter(double l, double w) {
        /*
         * Figure out what goes here
         */   
        
    }
    
}   
