/*
 * Assignment 5
 */
package numberloops;

/**
 *
 * @author anonymous
 */
public class NumberLoops {

    /**
     * This method takes two integers, n and m, and prints all the even squares inclusively between n and m
     * @param n any positive integer
     * @param m any integer greater than or equal to n
     */
    public static void evenSquares(int n, int m) {
        /*
         * Figure out what goes here
         */    
    }
    
    /**
     * This method takes two integers, n and m, and prints all the odd cubes inclusively between n and m
     * @param n any positive integer
     * @param m any integer greater than or equal to n
     */
    public static void oddCubes(int n, int m) {
        /*
         * Figure out what goes here
         */    
    }
     
    /**
     * This method takes two integers, n and m, and prints all the powers of three inclusively between n and m
     * @param n any positive integer
     * @param m any integer greater than or equal to n
     */
    public static void powersOfThree(int n, int m) {
        /*
         * Figure out what goes here
         */    
    }   
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Tests for evenSquares
        // Put your tests here
        
        // Tests for oddCubes
        // Put your tests here
        
        // Tests for powersOfThree
        // Put your tests here
    }
    
}
