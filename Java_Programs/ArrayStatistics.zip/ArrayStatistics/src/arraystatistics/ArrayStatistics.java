/*
 * Assignment 7 - Array Statistics
 */
package arraystatistics;
import java.util.Arrays;

/**
 *
 * @author anonymous
 */
public class ArrayStatistics {
    
    /**
     * This method takes an array of doubles and returns the lowest one
     * Example: lowestNum([-1.5, 4.1, -6.0, 10.06, 3.004]) => -6.0
     * 
     * If the array is empty, it returns 0.0
     * 
     * @param array an array of doubles
     * @return the lowest double in array; 0 if empty
     */
    public static double lowestNum(double[] array) {
        
    }

    /**
     * This method takes an array of ints and returns the product of all its even ints
     * Example: evenProduct([-1, 4, -6, 10, 3]) => -240
     * 
     * If there are no even ints or the array is empty, it returns 1
     * Example: evenProduct([1, 3, 5, 7]) => 1
     * 
     * @param array an array of ints
     * @return the product of all the even ints in array; 1 if there are none
     */
      public static int evenProduct(int[] array) {
          
    }
    
    /**
     * This method takes an array of chars and returns the least common char
     * Example: leastCommon(['a', 'a', 'w', 'h', 'w', 'a']) => 'h'
     * 
     * If there is a tie, it returns the one at the smallest index
     * Example: leastCommon(['a', 'a', 'w', 'h', 'h', 'w']) => 'a'
     * 
     * If the array is empty, it returns the char with ASCII value 0
     * 
     * @param array an array of characters
     * @return the least common character; character with ASCII value 0 if none
     */
      public static char leastCommon(char[] array) {
          
    }
      
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    }
    
}
