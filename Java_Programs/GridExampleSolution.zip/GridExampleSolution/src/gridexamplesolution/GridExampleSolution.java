/*
 * An example of a 2D array, with solutions to the practive problems
 */
package gridexamplesolution;
import java.util.Arrays;

/**
 *
 * @author Sarah
 */
public class GridExampleSolution {
    
    /**
     * This method returns the transpose of a 2D array of integers.
     * The transpose is the result when the rows become columns and vice versa.
     * 
     * @param grid a two-dimensional array of integers
     * @return the transpose of grid
     */
    public static int[][] transpose(int[][] grid) {
        int[][] gridT = new int[grid[0].length][grid.length];
        
        for (int i = 0; i < grid[0].length; i++) {
            for (int j = 0; j < grid.length; j++) {
                gridT[i][j] = grid[j][i];
            }
        }
        
        return gridT;
    }
    
    /**
     * This method returns the 2D array of integers with its rows reversed.
     * 
     * @param grid a two-dimensional array of integers
     * @return the grid with its rows reversed
     */
    public static int[][] reverseRows(int[][] grid) {
        int[][] gridR = new int[grid.length][grid[0].length];
        
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                gridR[i][j] = grid[i][grid[0].length - 1 - j];
            }
        }
        
        return gridR;
    }
    
    /**
     * This method returns the 2D array of integers with its columns reversed.
     * 
     * @param grid a two-dimensional array of integers
     * @return the grid with its rows reversed
     */
    public static int[][] reverseColumns(int[][] grid) {
        int[][] gridR = new int[grid.length][grid[0].length];
        
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                gridR[i][j] = grid[grid.length - 1 - i][j];
            }
        }
        
        return gridR;
    }
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[] row0 = {1, 2, 3, 4};
        int[] row1 = {5, 6, 7, 8};
        int[][] grid = {row0, row1};
        
        System.out.println("Here is the grid:");
        for (int[] row : grid) {
            System.out.println(Arrays.toString(row));
        }
        
        System.out.println();
        System.out.println("Here is the transpose of the grid:");
        for (int[] row : transpose(grid)) {
            System.out.println(Arrays.toString(row));
        }
        
        System.out.println();
        System.out.println("Here is the grid with each row reversed:");
        for (int[] row : reverseRows(grid)) {
            System.out.println(Arrays.toString(row));
        }

        System.out.println();
        System.out.println("Here is the grid with each column reversed:");
        for (int[] row : transpose(reverseRows(grid))) {
            System.out.println(Arrays.toString(row));
        }
    }
    
}
