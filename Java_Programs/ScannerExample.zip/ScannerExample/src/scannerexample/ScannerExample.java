/*
 * An example using the Scanner class to read files.
 */
package scannerexample;

// The program uses all the following classes, so they have to be imported
import java.io.File; 
import java.io.IOException;
import java.util.Scanner; 

/**
 *
 * @author Sarah
 */
public class ScannerExample {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException when the input file is missing or not readable
     */
    public static void main(String[] args) throws IOException {
        
        try {
            File inputFile = new File("input.txt"); 
            // scanner is going to scan the content of input.txt
            Scanner scanner = new Scanner(inputFile); 
            
            /* 
             * The hasNextLine method returns true when there is still one more
             * line left in the file.
             */
            while (scanner.hasNextLine()) {
                /* 
                 * The nextLine method returns the content of the current line
                 * and moves on to the next line 
                 */
                System.out.println(scanner.nextLine());
            }
        } catch(IOException exception) {
            /*
             * If input.txt doesn't exist or can't be read, information about this error
             * gets printed to the output window
             *
             * System.exit(0) is what causes "BUILD SUCCSSFUL" to print to the outut window
             */
            System.out.println("An error occurred.");
            System.out.println(exception);
            System.exit(0);
        } 
        
    } 

} 
